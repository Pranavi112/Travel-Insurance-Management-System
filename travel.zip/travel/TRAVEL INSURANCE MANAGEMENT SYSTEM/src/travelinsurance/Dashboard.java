package travelinsurance;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Dashboard extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JMenu mnucust,mnuply,mnuairl,mnupay,mnuplyc;
	private JMenuBar mnuBar;
	private JMenuItem miI1,miU1,miD1,miV1;
	private JMenuItem miI2,miU2,miD2,miV2;
	private JMenuItem miI3,miU3,miD3,miV3;
	private JMenuItem miI4,miU4,miD4,miV4;
	private JMenuItem miI5,miU5,miD5,miV5;
	private JTextField txtField;
	
	static JPanel p1;
	
	void initialize()
	{
		//po=new JPanel();
		p1=new JPanel();
		mnucust=new JMenu("Customer Details");
		mnuply=new JMenu("Book a policy");
		mnuairl=new JMenu("Flight Tickets");
		mnupay=new JMenu("Payment Mode");
		mnuplyc=new JMenu("Policy Claim");
		mnuBar=new JMenuBar();
		
		miI1=new JMenuItem("Insert");
		miU1=new JMenuItem("Update");
		miD1=new JMenuItem("Delete");
		miV1=new JMenuItem("View");
	
		miI2=new JMenuItem("Insert");
		miU2=new JMenuItem("Update");
		miD2=new JMenuItem("Delete");
		miV2=new JMenuItem("View");
		
		miI3=new JMenuItem("Insert");
		miU3=new JMenuItem("Update");
		miD3=new JMenuItem("Delete");
		miV3=new JMenuItem("View");
		
		miI4=new JMenuItem("Insert");
		miU4=new JMenuItem("Update");
		miD4=new JMenuItem("Delete");
		miV4=new JMenuItem("View");
		
		miI5=new JMenuItem("Insert");
		miU5=new JMenuItem("Update");
		miD5=new JMenuItem("Delete");
		miV5=new JMenuItem("View");
		
		
		
		
		txtField = new JTextField("TRAVEL INSURANCE MANAGEMENT SYSTEM"); 
		txtField.setFont(new Font("TimesRoman", Font.BOLD , 40));
		txtField.setEditable(false);
		txtField.setOpaque(true);
		txtField.setBackground(Color.cyan); 
	}
	void addComponentsToFrame()
	{
		mnucust.add(miI1);
		mnucust.add(miU1);
		mnucust.add(miD1);
		mnucust.add(miV1);
		

		mnuply.add(miI2);
		mnuply.add(miU2);
		mnuply.add(miD2);
		mnuply.add(miV2);
		
		mnuairl.add(miI3);
		mnuairl.add(miU3);
		mnuairl.add(miD3);
		mnuairl.add(miV3);
		
		
		mnupay.add(miI4);
		mnupay.add(miU4);
		mnupay.add(miD4);
		mnupay.add(miV4);
		
		
		mnuplyc.add(miI5);
		mnuplyc.add(miU5);
		mnuplyc.add(miD5);
		mnuplyc.add(miV5);
		
		
		mnuBar.add(mnucust);
		mnuBar.add(mnuply);
		mnuBar.add(mnuairl);
		mnuBar.add(mnupay);
		mnuBar.add(mnuplyc);
		setJMenuBar(mnuBar);
		
		
		p1.setLayout(new BorderLayout());
		p1.add(txtField,BorderLayout.CENTER);
		
		this.setLayout(new BorderLayout());
		add(p1,BorderLayout.CENTER);
		p1.setOpaque(true);
		p1.setBackground(Color.cyan);
	}
	void register()
	{
		Customer t1=new Customer(p1,Dashboard.this,miI1,miU1,miD1,miV1);
		t1.regis_customer();
		Policy t2=new Policy(p1,Dashboard.this,miI2,miU2,miD2,miV2);
		t2.regis_policy();
		Airlines t3=new Airlines(p1,Dashboard.this,miI3,miU3,miD3,miV3);
		t3.regis_policy();
		Payment t4=new Payment(p1, Dashboard.this, miI4, miU4, miD4, miV4);
		t4.regis_customer();
		Policyclaim t5=new Policyclaim(p1,Dashboard.this,miI5,miU5,miD5,miV5);
		t5.regis_policy();
		
		 addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent evt) 
				{
					
						
					  int a=JOptionPane.showConfirmDialog(Dashboard.this,"Are you sure?", "This will close the UI", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);  
					  if(a==JOptionPane.YES_OPTION)
					      Dashboard.this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
						
				}   
			 });

		
	}
	
	
	public Dashboard()
	{
		initialize();
		addComponentsToFrame();
		register();
		pack();
		setTitle("TRAVEL INSURANCE MANAGEMENT SYSTEM");
		setSize(600,500);
		setVisible(true);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
